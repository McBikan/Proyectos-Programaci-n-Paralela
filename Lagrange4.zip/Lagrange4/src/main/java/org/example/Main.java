package org.example;

import java.util.Random;
import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import javax.swing.*;


public class Main {
    public static void main(String[] args) {
        // Ejemplo de Uso
        int n = 4;

        int[] puntos = VectorNumerosAleatorios(n);

//        System.out.println("Números aleatorios generados:");
//        for (int i = 0; i < n; i++) {
//            System.out.println(puntos[i]);
//        }

        int[][] coordenadas = MatrizCoordenadas(puntos);

        System.out.println("Coordenadas aleatorias generadas:");
        for(int i = 0; i < n; i++){
            System.out.println( coordenadas[i][0] + " " + coordenadas[i][1] );
        }

//        String polinomio = polinomioLagrange(coordenadas);
//        System.out.println("Polinomio de Lagrange:");
//        System.out.println(polinomio);

        String polinomio = polinomioLagrangeSimplificado(coordenadas);
        System.out.println("Polinomio de Lagrange simplificado:");
        System.out.println(polinomio);

        double x = 3.5; // Punto de interpolación
        double valorInterpolado = interpolacionLagrange(x, coordenadas);
        System.out.println("El valor interpolado en x = " + x + " es: " + valorInterpolado);

        // Crear un conjunto de datos para las coordenadas del polinomio
        XYSeries series = new XYSeries("Polinomio de Lagrange");

        // Agregar los puntos del polinomio
        for (double x0 = -10; x0 <= 10; x0 += 0.1) {
            double y = evaluarPolinomioLagrange(x0); // Debes implementar esta función
            series.add(x0, y);
        }

        // Crear un conjunto de datos que contenga el conjunto de puntos
        XYSeriesCollection dataset = new XYSeriesCollection(series);

        // Crear el gráfico
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Polinomio de Lagrange", // Título del gráfico
                "x", // Etiqueta del eje x
                "y", // Etiqueta del eje y
                dataset // Conjunto de datos
        );

        // Mostrar el gráfico en una ventana
        SwingUtilities.invokeLater(() -> {
            // Crear un panel para mostrar el gráfico
            ChartPanel panel = new ChartPanel(chart);
            // Crear una ventana para mostrar el gráfico
            JFrame frame = new JFrame("Polinomio de Lagrange");
            // Agregar el panel al marco
            frame.getContentPane().add(panel);
            // Establecer las dimensiones del marco
            frame.setSize(800, 600);
            // Establecer la operación de cierre predeterminada
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // Mostrar el marco
            frame.setVisible(true);
        });

    }

    // Función para evaluar el polinomio de Lagrange en un valor dado de x
    public static double evaluarPolinomioLagrange(double x0) {
        // Debes implementar esta función para evaluar el polinomio de Lagrange en el valor dado de x
        // Puedes usar la implementación anterior que calcula el polinomio de Lagrange simplificado
        // o cualquier otra implementación que tengas disponible
        return 0.0; // Reemplaza esto con la evaluación real del polinomio de Lagrange en x
    }

    public static int[] VectorNumerosAleatorios(int n) {
        // Vector para almacenar los números aleatorios
        int[] puntos = new int[n];
        Random rand = new Random();

        // Generamos los números aleatorios en un rango de -100 a 100
        for (int i = 0; i < n; i++) {
            puntos[i] = rand.nextInt(201) - 100; //(max-min+1)+min;
        }
        return puntos;
    }

    public static int[][] MatrizCoordenadas(int[] puntos) {
        int n = puntos.length;
        // Matriz para almacenar las coordenadas
        int[][] coordenadas = new int[n][2];

        // Las x serán números consecutivos del 0 al n
        for (int i = 0; i < n; i++) {
            // Asignamos los valores a la primera columna
            coordenadas[i][0] = i;
            // Asignamos los valores del vector puntos a la segunda columna
            coordenadas[i][1] = puntos[i];
        }
        return coordenadas;
    }

//    public static String polinomioLagrange(int[][] coordenadas) {
//        StringBuilder polinomio = new StringBuilder();
//        for (int i = 0; i < coordenadas.length; i++) {
//            double xi = coordenadas[i][0];
//            double yi = coordenadas[i][1];
//            StringBuilder termino = new StringBuilder();
//            termino.append(yi);
//            for (int j = 0; j < coordenadas.length; j++) {
//                if (j != i) {
//                    double xj = coordenadas[j][0];
//                    termino.append(" * (x - ").append(xj).append(") / (").append(xi - xj).append(")");
//                }
//            }
//            if (i > 0) {
//                polinomio.append(" + ");
//            }
//            polinomio.append(termino);
//        }
//        return polinomio.toString();
//    }


    public static String polinomioLagrangeSimplificado(int[][] coordenadas) {
        double[] x = new double[coordenadas.length];
        double[] y = new double[coordenadas.length];
        for (int i = 0; i < coordenadas.length; i++) {
            x[i] = coordenadas[i][0];
            y[i] = coordenadas[i][1];
        }
        CustomPolynomialFunctionLagrangeForm lagrangeForm = new CustomPolynomialFunctionLagrangeForm(x, y);
        // Calcular los coeficientes del polinomio interpolador de Lagrange
        lagrangeForm.computeCoefficientsPublic();
        // Obtener los coeficientes del polinomio interpolador de Lagrange
        double[] coefficients = lagrangeForm.getCoefficients();
        // Crear un objeto PolynomialFunction con los coeficientes
        PolynomialFunction polinomio = new PolynomialFunction(coefficients);
        // Obtener una representación en forma de cadena del polinomio
        return polinomio.toString();
    }

    public static double interpolacionLagrange(double x, int[][] coordenadas) {
        double resultado = 0;
        for (int i = 0; i < coordenadas.length; i++) {
            double termino = coordenadas[i][1];
            for (int j = 0; j < coordenadas.length; j++) {
                if (j != i) {
                    termino *= (x - coordenadas[j][0]) / (coordenadas[i][0] - coordenadas[j][0]);
                }
            }
            resultado += termino;
        }
        return resultado;
    }


}
