package org.example;

import org.apache.commons.math3.analysis.polynomials.PolynomialFunctionLagrangeForm;

public class CustomPolynomialFunctionLagrangeForm extends PolynomialFunctionLagrangeForm {
    public CustomPolynomialFunctionLagrangeForm(double[] x, double[] y) {
        super(x, y);
    }

    public void computeCoefficientsPublic() {
        super.computeCoefficients();
    }
}